package com.example.examplemod.module.render;

import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

@SideOnly(Side.CLIENT)
public class GameSettings {
    public GameSettings() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && Minecraft.getMinecraft().player != null) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.gameSettings != null) {
                mc.gameSettings.gammaSetting = 5.0F;
                mc.gameSettings.viewBobbing = false;
                mc.gameSettings.enableVsync = false;
                mc.gameSettings.fancyGraphics = false;
            }
        }
    }
}