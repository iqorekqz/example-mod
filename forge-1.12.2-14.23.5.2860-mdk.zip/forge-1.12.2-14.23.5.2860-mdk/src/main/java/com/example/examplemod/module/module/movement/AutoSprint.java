package com.example.examplemod.module.module.movement;

import net.minecraft.init.MobEffects;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

public class AutoSprint {
    public AutoSprint() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.side == Side.CLIENT && e.phase == TickEvent.Phase.START) {
            if (!e.player.isSprinting()
                    && e.player.moveForward > 0
                    && !e.player.collidedHorizontally
                    && !e.player.isHandActive()
                    && !e.player.isPotionActive(MobEffects.WEAKNESS)
                    && e.player.getFoodStats().getFoodLevel() > 6
                    && !e.player.capabilities.isFlying
                    && !e.player.capabilities.isCreativeMode) {
                e.player.setSprinting(true);
            }
        }
    }
}